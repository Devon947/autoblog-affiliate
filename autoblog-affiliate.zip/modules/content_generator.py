# content_generator.py
