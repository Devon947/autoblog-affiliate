# autoposter_blogger.py
